# Project-TBANython

this project is made as a small toolkit for python devs and minecraft players.

This project has an in built python ide and minecraft launcher.it has a game  too.
plus a programming language 

you can edit this code for your personal use.


INSTALLATION
------------
-> you will need to download the latest version of tbanythonVM
from the releases page.
->I'll create a video about it 🤪
